﻿/// <summary>
/// @author Ganghuan Huang, Haoyin Li
/// @version 1.0
/// @date 2021/06/09
/// </summary>
namespace DBResourceManager
{
    static class Globals
    {
        //global mainDB connection string
        public static string mainDB = "Server=DESKTOP-J4BGRSJ;Database=TestDB1;User ID=Huang;Password=970327";
        //public static string mainDB = "Server=DESKTOP-JJUAM2E;Database=TestDB1;User ID=Huang;Password=970327";

        //global userDB connection string
        public static string userDB = "Server=DESKTOP-J4BGRSJ;Database=UserDB;User ID=Huang;Password=970327";
        //public static string userDB = "Server=DESKTOP-JJUAM2E;Database=UserDB;User ID=Huang;Password=970327";
    }
}

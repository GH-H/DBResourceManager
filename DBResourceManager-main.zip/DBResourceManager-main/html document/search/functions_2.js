var searchData=
[
  ['setacticity_15',['setActicity',['../class_d_b_resource_manager_1_1admin_monitor.html#aed8d43460066932d9a2fe6713ad84236',1,'DBResourceManager::adminMonitor']]],
  ['sethistory_16',['setHistory',['../class_d_b_resource_manager_1_1admin_monitor.html#a4c21086c69de34ac41a093a26e5c4cff',1,'DBResourceManager::adminMonitor']]]
];

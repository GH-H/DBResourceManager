var searchData=
[
  ['userlogin_6',['userLogin',['../class_d_b_resource_manager_1_1user_login.html',1,'DBResourceManager.userLogin'],['../class_d_b_resource_manager_1_1user_login.html#a00cef50e2dd6316eef7d73648da4ef37',1,'DBResourceManager.userLogin.userLogin()']]],
  ['usermain_7',['userMain',['../class_d_b_resource_manager_1_1user_main.html',1,'DBResourceManager.userMain'],['../class_d_b_resource_manager_1_1user_main.html#afd181f8efadc9dc708dd494719f6cc37',1,'DBResourceManager.userMain.userMain()']]]
];

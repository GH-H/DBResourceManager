var searchData=
[
  ['userlogin_9',['userLogin',['../class_d_b_resource_manager_1_1user_login.html',1,'DBResourceManager']]],
  ['usermain_10',['userMain',['../class_d_b_resource_manager_1_1user_main.html',1,'DBResourceManager']]]
];

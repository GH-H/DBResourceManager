var searchData=
[
  ['dbresourcemanager_11',['DBResourceManager',['../namespace_d_b_resource_manager.html',1,'']]]
];

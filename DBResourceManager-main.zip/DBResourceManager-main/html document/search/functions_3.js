var searchData=
[
  ['userlogin_17',['userLogin',['../class_d_b_resource_manager_1_1user_login.html#a00cef50e2dd6316eef7d73648da4ef37',1,'DBResourceManager::userLogin']]],
  ['usermain_18',['userMain',['../class_d_b_resource_manager_1_1user_main.html#afd181f8efadc9dc708dd494719f6cc37',1,'DBResourceManager::userMain']]]
];

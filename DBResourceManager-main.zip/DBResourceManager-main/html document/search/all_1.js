var searchData=
[
  ['dbresourcemanager_2',['DBResourceManager',['../namespace_d_b_resource_manager.html',1,'']]],
  ['dispose_3',['Dispose',['../class_d_b_resource_manager_1_1admin_monitor.html#ac7e6b87c882b3498e6149365983ae091',1,'DBResourceManager.adminMonitor.Dispose()'],['../class_d_b_resource_manager_1_1user_main.html#af9103d9ffb62e087ebd7066b1f21d14c',1,'DBResourceManager.userMain.Dispose()'],['../class_d_b_resource_manager_1_1user_login.html#a19ecb4310d560e2e3f92828ed1e66098',1,'DBResourceManager.userLogin.Dispose()']]]
];

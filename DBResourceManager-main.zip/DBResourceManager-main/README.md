# DBResourceManager

## Intro
 This project was influenced  by the idea of Open source, we intend to build an “resource management” layer on top of database systems, making private database public accessible . Our Database resource management system provides features that monitor and control resource usage, as well as  flexible query access and user friendly interface.


## Project proposal
https://docs.google.com/document/d/1Y9skHW71MAg6SWP-WA-tH-jyQZO4CFRkYWuo9MqUwZg/edit?usp=sharing

## Final report
https://docs.google.com/document/d/1ksrUJREdMnZHWIlD5aI4P1V9ezixKMjwqNnBOla97YI/edit

## video 
https://drive.google.com/file/d/1pxtz_QWOkHW_8AnFr56JhwgdLgavOiFz/view?usp=sharing
## Design

![image](https://github.com/WebDataScience/DBResourceManager/blob/main/system%20routine%20.png)
![image](https://github.com/WebDataScience/DBResourceManager/blob/main/system%20architecture.png)
